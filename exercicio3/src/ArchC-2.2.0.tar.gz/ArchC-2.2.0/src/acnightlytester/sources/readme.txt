This folder should contain all compressed packages used by nightlytester
script. The packages itself are not under version control due to their size,
but they can be obtained manually.
